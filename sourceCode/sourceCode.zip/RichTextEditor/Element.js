//Constructor 
Microsoft.js.ui.Element = function(elementId)
{
  var uiElement = Microsoft.js.Dom.getElementById(elementId);
  
  // Element not found
  if(!uiElement)
   return null;
   
  this.uiElement = uiElement; 
  this.id = uiElement.id;
}

// Focus this element
Microsoft.js.ui.Element.prototype.Focus = function()
{
    try
    {
      this.uiElement.focus();
    }
    catch(e){}
        
    return this;
}

// Add a class name to the element
Microsoft.js.ui.Element.prototype.AddClass = function(className)
{
        if(className instanceof Array)
        {
            for(var i = 0, len = className.length; i < len; i++) 
            {
            	this.AddClass(className[i]);
            }
            
        }
        else
        {
            if(!this.HasClass(className))
            {
                this.uiElement.className = this.uiElement.className + ' ' + className;
            }
        }
        return this;
}

// Remove the class name from this ui element
Microsoft.js.ui.Element.prototype.RemoveClass = function(className)
{
    if(className instanceof Array)
    {
        for(var i = 0, len = className.length; i < len; i++) 
        {
        	this.removeClass(className[i]);
        }
    }
    else
    {
        var re = new RegExp('(?:^|\\s+)' + className + '(?:\\s+|$)', 'g');
        var c = this.uiElement.className;
        if(re.test(c))
        {
            this.uiElement.className = c.replace(re, ' ');
        }
    }
    return this;
}

//. Replace an existing class name for this element
Microsoft.js.ui.Element.prototype.ReplaceClass = function(prevClassName,newClassName)
{
   this.RemoveClass(prevClassName);
   this.AddClass(newClassName);
}

// Does the element have this classname assigned to it
Microsoft.js.ui.Element.prototype.HasClass = function(className)
{
        var re = new RegExp('(?:^|\\s+)' + className + '(?:\\s+|$)');
        return re.test(this.uiElement.className);
}

// Static method to find an element.
Microsoft.js.ui.Element.find = function(element)
{
    if(!element){ return null; }

    if(element instanceof Microsoft.js.ui.Element)
    {
      element.uiElement = Microsoft.js.Dom.getElementById(element.Id);
      return element;
    }
    else if(typeof element == 'string') // must be an id
    {
       var elem = new Microsoft.js.ui.Element(element);
       return elem;
    }
    else
       return null;
}