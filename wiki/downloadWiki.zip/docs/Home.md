# NOTE: The [AJAX Control Toolkit](http://ajaxcontroltoolkit.codeplex.com) contains an HTML Editor that is more mature than this project.

The key feature of the RTE is to support **WYSIWYG** along with the following generic feature set below. The key goal has been to encapsulate all the complex functionality of web based rich text editing into a single control. 

All that you need is to drop the control dll into your bin directory, and include a single tag like **<cc1:RichTextEditor ID="Rte1" Theme="Blue" runat="server" />** to get the full rich text editor working on your page!. You can use the Culture attribute to set it for use with other supported languages listed below.

**Download:** If you're wanting to download the latest stable bits, use the "Releases" tab, and if you want to get the latest source code bits, check out the "Source Code" tab.

**Supported Browsers:** Internet Explorer and FireFox
**Live demo:** See this Rich Text Editor in action at the [live demo site!](http://rteditor.members.winisp.net/)
**Supported Styles / Formats:** Bold, Italic, Underline, Justify, indentations, Plain Lists, Numbered Lists
**Supported Commands:** Copy, Paste, Cut, Add Hyperlink, Set Foreground Color, Set Highlight Color, Set Fonts, Set Font Sizes, Insert Smiles
**Supported Views:** Text View, Html View
**Localization:** Supported Languages include en-us, cs-cz, es-es, de-de, fr-fr, it-it, ja-jp, ko-kr, pt-br, ru-ru, zh-cn, zh-hk, zh-tw

![](Home_Rte.png)